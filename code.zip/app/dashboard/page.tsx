"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { DashboardNav } from "@/components/dashboard-nav"
import { ProfilePage } from "@/components/pages/profile-page"
import { WardrobePage } from "@/components/pages/wardrobe-page"
import { AddOutfitPage } from "@/components/pages/add-outfit-page"
import { DailySuggestionPage } from "@/components/pages/daily-suggestion-page"
import { HomePage } from "@/components/pages/home-page"
import { BuyOutfitsPage } from "@/components/pages/buy-outfits-page"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("home")
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        redirect("/login")
      }
      setUser(user)
      setLoading(false)
    }

    checkUser()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-secondary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "home" && <HomePage user={user} />}
        {activeTab === "profile" && <ProfilePage user={user} />}
        {activeTab === "wardrobe" && <WardrobePage user={user} />}
        {activeTab === "add-outfit" && <AddOutfitPage user={user} />}
        {activeTab === "suggestions" && <DailySuggestionPage user={user} />}
        {activeTab === "buy-outfits" && <BuyOutfitsPage user={user} />}
      </main>
    </div>
  )
}
