"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Menu, Home, User, ShoppingBag, Plus, Sparkles, LogOut, X } from "lucide-react"

interface DashboardNavProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function DashboardNav({ activeTab, onTabChange }: DashboardNavProps) {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/login")
  }

  const navItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "profile", label: "My Profile", icon: User },
    { id: "wardrobe", label: "My Wardrobe", icon: ShoppingBag },
    { id: "add-outfit", label: "Add Outfit", icon: Plus },
    { id: "suggestions", label: "Daily Suggestion", icon: Sparkles },
    { id: "buy-outfits", label: "Buy Outfits", icon: ShoppingBag },
  ]

  return (
    <>
      <nav className="bg-primary border-b border-secondary/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-secondary rounded-lg flex items-center justify-center">
                <span className="text-primary font-bold">W</span>
              </div>
              <span className="text-xl font-bold text-secondary hidden sm:inline">WARDROBIA</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => onTabChange(id)}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${
                    activeTab === id ? "bg-secondary/20 text-secondary" : "text-foreground hover:bg-secondary/10"
                  }`}
                >
                  <Icon size={18} />
                  <span className="text-sm">{label}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-destructive hover:bg-destructive/10"
              >
                <LogOut size={18} />
                <span className="hidden sm:inline">Logout</span>
              </Button>

              {/* Mobile Menu Toggle */}
              <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 hover:bg-secondary/10 rounded-lg">
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <div className="md:hidden pb-4 space-y-2 border-t border-secondary/20 pt-4">
              {navItems.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => {
                    onTabChange(id)
                    setIsOpen(false)
                  }}
                  className={`w-full text-left px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${
                    activeTab === id ? "bg-secondary/20 text-secondary" : "text-foreground hover:bg-secondary/10"
                  }`}
                >
                  <Icon size={18} />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>
    </>
  )
}
