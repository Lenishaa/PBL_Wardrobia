"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sparkles } from "lucide-react"

const EVENT_TYPES = ["Casual", "Office", "Party", "Formal", "Beach", "Gym", "Date", "Wedding"]

const WEATHER_CONDITIONS = ["Sunny", "Rainy", "Cold", "Hot", "Humid", "Windy", "Cloudy"]

export function DailySuggestionPage({ user }: { user: any }) {
  const [location, setLocation] = useState("")
  const [eventType, setEventType] = useState("")
  const [weather, setWeather] = useState("")
  const [suggestion, setSuggestion] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const handleGenerateSuggestion = async () => {
    setLoading(true)

    // Simulate AI suggestion - in production, this would call an AI model
    setTimeout(() => {
      setSuggestion({
        event: eventType,
        location,
        weather,
        suggestions: [
          {
            category: "Top",
            recommendation: "Light breathable fabric",
            reason: `Perfect for ${weather} weather`,
          },
          {
            category: "Bottom",
            recommendation: "Comfortable fit",
            reason: `Ideal for ${eventType}`,
          },
          {
            category: "Accessories",
            recommendation: "Minimal jewelry",
            reason: "Keeps look fresh and casual",
          },
        ],
      })
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Daily Outfit Suggestion</h1>
        <p className="text-muted-foreground">Get personalized outfit recommendations based on weather and events</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="text-secondary" />
            Create Suggestion
          </CardTitle>
          <CardDescription>Tell us about your day</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Location</Label>
              <Input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Office, Beach, Park"
              />
            </div>

            <div className="space-y-2">
              <Label>Event Type</Label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md"
              >
                <option value="">Select event type</option>
                {EVENT_TYPES.map((event) => (
                  <option key={event} value={event}>
                    {event}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label>Weather</Label>
              <select
                value={weather}
                onChange={(e) => setWeather(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md"
              >
                <option value="">Select weather</option>
                {WEATHER_CONDITIONS.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Button
            onClick={handleGenerateSuggestion}
            className="w-full bg-secondary text-primary hover:bg-secondary/90"
            disabled={loading || !location || !eventType || !weather}
          >
            {loading ? "Generating..." : "Generate Suggestion"}
          </Button>
        </CardContent>
      </Card>

      {suggestion && (
        <Card>
          <CardHeader>
            <CardTitle>Your Daily Outfit</CardTitle>
            <CardDescription>
              Outfit for {suggestion.event} in {suggestion.location} ({suggestion.weather})
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {suggestion.suggestions.map((item: any, idx: number) => (
                <div
                  key={idx}
                  className="border border-secondary/20 rounded-lg p-4 hover:bg-secondary/5 transition-colors"
                >
                  <h4 className="font-semibold text-secondary mb-1">{item.category}</h4>
                  <p className="text-foreground mb-2">{item.recommendation}</p>
                  <p className="text-sm text-muted-foreground">💡 {item.reason}</p>
                </div>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-4 mt-6">
              <Button variant="outline" className="w-full bg-transparent" onClick={() => setSuggestion(null)}>
                Get Another Suggestion
              </Button>
              <Button className="w-full bg-secondary text-primary hover:bg-secondary/90">Save This Outfit</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
