"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"

const CATEGORIES = {
  male: ["Shirts", "Pants", "Ethnic Wear"],
  female: ["Tops", "Pants", "Dresses", "Sarees"],
}

export function WardrobePage({ user }: { user: any }) {
  const [wardrobe, setWardrobe] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedGender, setSelectedGender] = useState<"male" | "female">("male")
  const supabase = createClient()

  useEffect(() => {
    const fetchWardrobe = async () => {
      const { data } = await supabase
        .from("wardrobe")
        .select("*")
        .eq("user_id", user.id)
        .eq("gender", selectedGender)
        .order("created_at", { ascending: false })

      setWardrobe(data || [])
      setLoading(false)
    }

    fetchWardrobe()
  }, [user.id, selectedGender])

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      await supabase.from("wardrobe").delete().eq("id", id)
      setWardrobe(wardrobe.filter((item) => item.id !== id))
    }
  }

  if (loading) {
    return <p className="text-center text-muted-foreground">Loading wardrobe...</p>
  }

  const categories = selectedGender === "male" ? CATEGORIES.male : CATEGORIES.female

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Wardrobe</h1>
        <p className="text-muted-foreground">Manage your outfit collection</p>
      </div>

      <div className="flex gap-4 mb-6">
        <Button
          onClick={() => setSelectedGender("male")}
          className={selectedGender === "male" ? "bg-secondary text-primary hover:bg-secondary/90" : "bg-muted"}
        >
          Men's Collection
        </Button>
        <Button
          onClick={() => setSelectedGender("female")}
          className={selectedGender === "female" ? "bg-secondary text-primary hover:bg-secondary/90" : "bg-muted"}
        >
          Women's Collection
        </Button>
      </div>

      {wardrobe.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-muted-foreground mb-4">No items in {selectedGender}'s wardrobe yet</p>
            <Button className="bg-secondary text-primary hover:bg-secondary/90">Add Your First Item</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {categories.map((category) => {
            const categoryItems = wardrobe.filter((item) => item.category.toLowerCase() === category.toLowerCase())

            return (
              <div key={category}>
                <h2 className="text-xl font-semibold mb-4">{category}</h2>
                <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {categoryItems.map((item) => (
                    <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <CardContent className="p-0 relative group">
                        <div className="aspect-square bg-muted overflow-hidden">
                          {item.image_url ? (
                            <img
                              src={item.image_url || "/placeholder.svg"}
                              alt={item.category}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-muted">
                              <span className="text-muted-foreground">No image</span>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="absolute top-2 right-2 p-2 bg-destructive rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 size={16} className="text-white" />
                        </button>
                      </CardContent>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base">{item.category}</CardTitle>
                        {item.color && <CardDescription className="capitalize">{item.color}</CardDescription>}
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
