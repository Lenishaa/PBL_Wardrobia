"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Upload } from "lucide-react"

const CATEGORIES = {
  male: ["Shirts", "Pants", "Ethnic Wear"],
  female: ["Tops", "Pants", "Dresses", "Sarees"],
}

const COLORS = [
  "Red",
  "Blue",
  "Green",
  "Yellow",
  "Black",
  "White",
  "Gray",
  "Brown",
  "Purple",
  "Pink",
  "Orange",
  "Beige",
]

const SEASONS = ["Summer", "Winter", "Monsoon", "All-season"]

export function AddOutfitPage({ user }: { user: any }) {
  const [gender, setGender] = useState<"male" | "female">("male")
  const [category, setCategory] = useState("")
  const [color, setColor] = useState("")
  const [season, setSeason] = useState("")
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState("")
  const [loading, setLoading] = useState(false)
  const supabase = createClient()

  const categories = gender === "male" ? CATEGORIES.male : CATEGORIES.female

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      let imageUrl = ""

      if (imageFile) {
        const fileName = `${user.id}/${Date.now()}-${imageFile.name}`
        const { data, error: uploadError } = await supabase.storage.from("wardrobe-images").upload(fileName, imageFile)

        if (uploadError) throw uploadError

        const { data: urlData } = supabase.storage.from("wardrobe-images").getPublicUrl(fileName)

        imageUrl = urlData.publicUrl
      }

      const { error } = await supabase.from("wardrobe").insert({
        user_id: user.id,
        category,
        gender,
        color,
        season,
        image_url: imageUrl,
      })

      if (error) throw error

      // Reset form
      setCategory("")
      setColor("")
      setSeason("")
      setImageFile(null)
      setImagePreview("")
      alert("Outfit added successfully!")
    } catch (error) {
      console.error("Error adding outfit:", error)
      alert("Error adding outfit. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Add Outfit</h1>
        <p className="text-muted-foreground">Upload new items to your wardrobe collection</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New Item</CardTitle>
          <CardDescription>Fill in the details and upload an image</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Gender</Label>
                <select
                  value={gender}
                  onChange={(e) => {
                    setGender(e.target.value as "male" | "female")
                    setCategory("")
                  }}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label>Category</Label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  required
                >
                  <option value="">Select category</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label>Color</Label>
                <select
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  required
                >
                  <option value="">Select color</option>
                  {COLORS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label>Season</Label>
                <select
                  value={season}
                  onChange={(e) => setSeason(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  required
                >
                  <option value="">Select season</option>
                  {SEASONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <Label>Upload Image</Label>
              <div className="border-2 border-dashed border-secondary/30 rounded-lg p-8 text-center hover:border-secondary/50 transition-colors">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                  required
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  {imagePreview ? (
                    <div className="space-y-2">
                      <img
                        src={imagePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-64 mx-auto rounded"
                      />
                      <p className="text-sm text-secondary">Change image</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="mx-auto text-secondary" size={32} />
                      <p className="text-foreground font-medium">Click to upload image</p>
                      <p className="text-xs text-muted-foreground">PNG, JPG, GIF up to 10MB</p>
                    </div>
                  )}
                </label>
              </div>
            </div>

            <Button type="submit" className="w-full bg-secondary text-primary hover:bg-secondary/90" disabled={loading}>
              {loading ? "Adding..." : "Add to Wardrobe"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
