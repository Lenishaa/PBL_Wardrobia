"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, ShoppingBag, Plus, User } from "lucide-react"

export function HomePage({ user }: { user: any }) {
  const [profile, setProfile] = useState<any>(null)
  const supabase = createClient()

  useEffect(() => {
    const fetchProfile = async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single()
      setProfile(data)
    }

    fetchProfile()
  }, [user.id])

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-text-balance mb-2">Welcome Back, {profile?.name || "Fashionista"}!</h1>
        <p className="text-muted-foreground">Let's find the perfect outfit for today</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="text-secondary" size={20} />
              Daily Suggestion
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Get AI-powered outfit suggestions</p>
            <Button size="sm" className="w-full bg-secondary text-primary hover:bg-secondary/90">
              View Suggestion
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="text-secondary" size={20} />
              My Wardrobe
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Browse your outfit collection</p>
            <Button size="sm" className="w-full bg-secondary text-primary hover:bg-secondary/90">
              View Wardrobe
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Plus className="text-secondary" size={20} />
              Add Outfit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Upload new items to your wardrobe</p>
            <Button size="sm" className="w-full bg-secondary text-primary hover:bg-secondary/90">
              Add Item
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <User className="text-secondary" size={20} />
              Profile
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Update your preferences</p>
            <Button size="sm" className="w-full bg-secondary text-primary hover:bg-secondary/90">
              Edit Profile
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Stats</CardTitle>
          <CardDescription>Your wardrobe at a glance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">0</div>
              <p className="text-muted-foreground text-sm">Total Items</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">0</div>
              <p className="text-muted-foreground text-sm">Categories</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">0</div>
              <p className="text-muted-foreground text-sm">Suggestions</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
