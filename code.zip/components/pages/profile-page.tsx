"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const SKIN_TONES = ["Fair", "Light", "Medium", "Olive", "Tan", "Deep"]
const BODY_TYPES_FEMALE = ["Hourglass", "Pear", "Apple", "Rectangle", "Inverted Triangle"]
const BODY_TYPES_MALE = ["Inverted Triangle", "Rectangle", "Oval", "Triangle"]

export function ProfilePage({ user }: { user: any }) {
  const [profile, setProfile] = useState<any>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const supabase = createClient()

  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "male",
    skin_tone: "",
    body_type: "",
  })

  useEffect(() => {
    const fetchProfile = async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (data) {
        setProfile(data)
        setFormData({
          name: data.name || "",
          age: data.age || "",
          gender: data.gender || "male",
          skin_tone: data.skin_tone || "",
          body_type: data.body_type || "",
        })
      }
      setLoading(false)
    }

    fetchProfile()
  }, [user.id])

  const handleSave = async () => {
    setSaving(true)
    try {
      const { error } = await supabase.from("profiles").update(formData).eq("id", user.id)

      if (error) throw error

      setProfile({ ...profile, ...formData })
      setIsEditing(false)
    } catch (error) {
      console.error("Error updating profile:", error)
    } finally {
      setSaving(false)
    }
  }

  const bodyTypeOptions = formData.gender === "female" ? BODY_TYPES_FEMALE : BODY_TYPES_MALE

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-muted-foreground">Loading profile...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Profile</h1>
        <p className="text-muted-foreground">Manage your personal preferences and information</p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Your personal details and preferences</CardDescription>
          </div>
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant={isEditing ? "outline" : "default"}
            className={isEditing ? "" : "bg-secondary text-primary hover:bg-secondary/90"}
          >
            {isEditing ? "Cancel" : "Edit Profile"}
          </Button>
        </CardHeader>

        <CardContent className="space-y-6">
          {isEditing ? (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your full name"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Age</Label>
                  <Input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                    placeholder="Your age"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Gender</Label>
                  <select
                    value={formData.gender}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        gender: e.target.value,
                        body_type: "",
                      })
                    }
                    className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Skin Tone</Label>
                  <select
                    value={formData.skin_tone}
                    onChange={(e) => setFormData({ ...formData, skin_tone: e.target.value })}
                    className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  >
                    <option value="">Select skin tone</option>
                    {SKIN_TONES.map((tone) => (
                      <option key={tone} value={tone}>
                        {tone}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Body Type</Label>
                  <select
                    value={formData.body_type}
                    onChange={(e) => setFormData({ ...formData, body_type: e.target.value })}
                    className="w-full px-3 py-2 border border-input bg-background rounded-md"
                  >
                    <option value="">Select body type</option>
                    {bodyTypeOptions.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={user.email} disabled className="bg-muted" />
                </div>
              </div>

              <Button
                onClick={handleSave}
                className="w-full bg-secondary text-primary hover:bg-secondary/90"
                disabled={saving}
              >
                {saving ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Name</p>
                  <p className="text-lg">{profile?.name || "Not set"}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground">Age</p>
                  <p className="text-lg">{profile?.age || "Not set"}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground">Gender</p>
                  <p className="text-lg capitalize">{profile?.gender || "Not set"}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground">Skin Tone</p>
                  <p className="text-lg">{profile?.skin_tone || "Not set"}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground">Body Type</p>
                  <p className="text-lg">{profile?.body_type || "Not set"}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground">Email</p>
                  <p className="text-lg">{user.email}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Google Calendar Integration</CardTitle>
          <CardDescription>Connect your Google Calendar to get location and event-based suggestions</CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant="outline"
            className="w-full bg-transparent"
            onClick={() => alert("Google Calendar integration coming soon!")}
          >
            Connect Google Calendar
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
