"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ShoppingBag, ExternalLink } from "lucide-react"

const SHOPPING_PLATFORMS = [
  {
    name: "Amazon",
    url: "https://www.amazon.in/",
    description: "Fast delivery and wide variety",
    color: "bg-orange-500",
  },
  {
    name: "Flipkart",
    url: "https://www.flipkart.com/",
    description: "Great deals and exclusive brands",
    color: "bg-blue-600",
  },
  {
    name: "Meesho",
    url: "https://www.meesho.com/",
    description: "Affordable and trendy fashion",
    color: "bg-pink-500",
  },
]

export function BuyOutfitsPage({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Buy Outfits</h1>
        <p className="text-muted-foreground">Shop for clothing from your favorite retailers</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {SHOPPING_PLATFORMS.map((platform) => (
          <Card key={platform.name} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className={`w-12 h-12 ${platform.color} rounded-lg flex items-center justify-center mb-4`}>
                <ShoppingBag size={24} className="text-white" />
              </div>
              <CardTitle>{platform.name}</CardTitle>
              <CardDescription>{platform.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <a href={platform.url} target="_blank" rel="noopener noreferrer">
                <Button className="w-full bg-secondary text-primary hover:bg-secondary/90">
                  <ExternalLink size={16} className="mr-2" />
                  Shop Now
                </Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Shopping Tips</CardTitle>
          <CardDescription>Make the most of your shopping experience</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-semibold">Filter by Your Style</h4>
            <p className="text-sm text-muted-foreground">
              Use the search filters to find items that match your body type and skin tone
            </p>
          </div>
          <div className="space-y-2">
            <h4 className="font-semibold">Compare Prices</h4>
            <p className="text-sm text-muted-foreground">
              Check all platforms to find the best deals on your favorite items
            </p>
          </div>
          <div className="space-y-2">
            <h4 className="font-semibold">Save for Later</h4>
            <p className="text-sm text-muted-foreground">Add items to your wishlist to keep track of things you want</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
